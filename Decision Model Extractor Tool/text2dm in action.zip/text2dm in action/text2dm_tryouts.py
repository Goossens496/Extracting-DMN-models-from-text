# TRYOUTS of text2dm python package
# other option use the graphical user interface in user_interface.py (works for single test examples)
import text2dm
import pandas as pd
desired_width = 100
pd.set_option('display.width', desired_width)
pd.set_option('display.max_columns', 5)


# DRD TUPLE EXTRACTION FROM SINGLE EXAMPLE
def tuple_single_example():
    input = 'Playing tennis depends on the weather which is influenced by the season. The season follows from the date.'
    result_tuple = text2dm.text2drd(input)
    print('DRD TUPLE EXTRACTION FROM SINGLE EXAMPLE')
    print(result_tuple)
    print()


# DRD GRAPH EXTRACTION FROM SINGLE EXAMPLE
def drd_graph():
    input = 'Playing tennis depends on the weather which is influenced by the season. The season follows from the date.'
    result_graph, final_decision_id = text2dm.get_drd_graph(input)
    result_graph.format = 'pdf'   # png also possible
    # save to pdf in text2dm in action
    result_graph.render("results tryouts/DRD_" + final_decision_id)  # view=True if you want the visualization to pop up


# XML EXTRACTION
def xml():
    input = 'Playing tennis depends on the weather which is influenced by the season. The season follows from the date.'
    xmlstr = text2dm.get_xml(input)
    #print(xmlstr)
    with open("results tryouts/xml_DRD.dmn", "w") as f:
        # write xml to dmn file
        f.write(xmlstr)
    return xmlstr


# DRD EXTRACTION FROM MULTIPLE EXAMPLES
# input: dataframe with column 'test example'
# output: dataframe with column 'test example' and 'drd tuple'
def drd_multiple():
    df_test = pd.read_csv('results tryouts/test_examples.csv')
    df_result = text2dm.get_multiple_drd_tuples(df_test)
    print('DRD TUPLE EXTRACTION FROM MULTIPLE EXAMPLES')
    print(df_result)
    print()
    # optional write to csv (see results tryouts)
    df_result.to_csv('results tryouts/test_results_drd.csv')


# LOGIC TABLE EXTRACTION
def logic_table():
    input_logic = 'Your discount is determined from age. If your age is lower than 20, you get 10% discount. Otherwise the discount is 5%.'
    df_result_logic = text2dm.extract_logic_table(input_logic)
    print('LOGIC TABLE EXTRACTION')
    print(df_result_logic)
    print()
    # optional write to csv (see results tryouts)
    df_result_logic.to_csv('results tryouts/test_result_logic.csv')


if __name__ == "__main__":
    # choose here what you want to test
    tuple_single_example()
